﻿namespace Com.Cognizant.Truyum.Dao
{
   public class Constants
    {
        public static string menuId = "me_id";
        public static string menuName ="me_name";
        public static string menuPrice ="me_price";
        public static string menuActive = "me_active";
        public static string valueYes = "Yes";
        public static string valueNo = "No";
        public static string menuDateOfLaunch = "me_date_of_launch";
        public static string menuCategory = "me_category";
        public static string menuFreeDelivery = "me_free_delivery";

        public static string atId = "@id";
        public static string atName= "@name";
        public static string atPrice ="@price";
        public static string atActive = "@active";
        public static string atDateOfLaunch = "@dateOfLaunch";
        public static string atCategory= "@category";       
        public static string atFreeDelivery = "@freeDelivery";

        public static string atUserId = "@userId";
        public static string atMenuId = "@menuId";

    }
}

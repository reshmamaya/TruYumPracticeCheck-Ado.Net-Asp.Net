﻿using System;
using System.Collections.Generic;
//class file
//namespace
using System.Data;
using System.Data.SqlClient;
//namespace for model
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
    public class CartDaoSQL:ICartDao
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        /// <summary>
        /// This method is used to add the product to the cart by the user
        /// </summary>
        /// <param name="userId">This parameter indicates which user is adding the product</param>
        /// <param name="productId">This parameter indicates the id of the product </param>
        public void AddCartItem(long userId,long productId)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries._addCartData
                };

                command.Parameters.Add(Constants.atUserId,SqlDbType.Int).Value = userId;
                command.Parameters.Add(Constants.atMenuId, SqlDbType.Int).Value = productId;

                command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// This menthod is used to get all the items present in the cart
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Returns the Object of cart</returns>
        public Cart GetAllCartItems(long userId)
        {
            Cart cart = new Cart();
            List<MenuItem> menuList = new List<MenuItem>();

            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries._getAllCartItems
                };

                command.Parameters.Add(Constants.atUserId, SqlDbType.Int).Value = userId;

                SqlDataReader dataReader = command.ExecuteReader();
                int count = 0;

                while (dataReader.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuId)));
                    menu.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuName)));
                    menu.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuPrice)));
                    menu.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuActive))).Equals(Constants.valueYes, StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menu.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuDateOfLaunch)));
                    menu.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuCategory)));
                    menu.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuFreeDelivery))).Equals(Constants.valueYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    count++;
                    menuList.Add(menu);
                }
                //dataReader.Close();
                if(count == 0) // ie no item in the cart
                {
                    throw new CartEmptyException();
                }

                cart.MenuItemList = menuList;
                dataReader.Close();

                SqlCommand command1 = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries._countTotal
                };

                command1.Parameters.Add(Constants.atUserId, SqlDbType.Int).Value = userId;

                SqlDataReader dataReader1 = command1.ExecuteReader();

                while(dataReader1.Read())
                {
                    cart.Total = Convert.ToDouble(dataReader1.GetValue(dataReader1.GetOrdinal("Total")));
                }

            }

            return cart;
        }
        /// <summary>
        /// This method is used to remove the item present in the cart using the id given 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="productId"></param>
        public void RemoveCartItem(long userId,long productId)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries._deleteItem
                };

                command.Parameters.Add(Constants.atUserId, SqlDbType.Int).Value = userId;
                command.Parameters.Add(Constants.atMenuId, SqlDbType.Int).Value = productId;

                command.ExecuteNonQuery();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
//class file
//namespace
using System.Data;
using System.Data.SqlClient;

using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao{
    public class MenuItemDaoSQL:IMenuItemDao{

        static string callConnection = ConnectionHandler.ConnectionVariable;

        /// <summary>
        /// This method is used to get the itemlist that present in the admin
        /// </summary>
        /// <returns> menu item  stored in a list is returned</returns>
        public List<MenuItem> GetMenuItemListAdmin(){
            List<MenuItem> menuList = new List<MenuItem>();        
            using (SqlConnection connection = new SqlConnection(callConnection)){
                connection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._getDataAdmin
                };
                SqlDataReader dataReader = command.ExecuteReader();
                while(dataReader.Read()){
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuId)));
                    menu.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuName)));
                    menu.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuPrice)));
                    menu.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuActive))).Equals(Constants.valueYes,StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menu.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuDateOfLaunch)));
                    menu.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuCategory)));
                    menu.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuFreeDelivery))).Equals(Constants.valueYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                }
            }

            return menuList;
        }

        /// <summary>
        /// This method is used to get the itemlist that present in the Customer
        /// </summary>
        /// <returns>menu item  stored in a list is returned</returns>
        public List<MenuItem> GetMenuItemListCustomer(){
            List<MenuItem> menuList = new List<MenuItem>();
            using (SqlConnection connection = new SqlConnection(callConnection)){
                connection.Open();
                SqlCommand command = new SqlCommand{
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._getDataCustomer
                };
                SqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read()){ 
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuId)));
                    menu.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuName)));
                    menu.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuPrice)));
                    menu.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuActive))).Equals(Constants.valueYes, StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menu.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuDateOfLaunch)));
                    menu.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuCategory)));
                    menu.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuFreeDelivery))).Equals(Constants.valueYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                }
            }

            return menuList;
        }
        /// <summary>
        /// This menthod is used to modify the items that is present in the menuItem 
        /// </summary>
        /// <param name="menuItem"> It is a object of the class MenuItem which contains the entire list of menu</param>
        public void ModifyMenuItem(MenuItem menuItem){
            using (SqlConnection connection = new SqlConnection(callConnection)){
                connection.Open();
                SqlCommand command = new SqlCommand{
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._updateItem
                };

                command.Parameters.Add(Constants.atName,SqlDbType.VarChar).Value = menuItem.Name;
                command.Parameters.Add(Constants.atPrice, SqlDbType.Decimal).Value = menuItem.Price;
                command.Parameters.Add(Constants.atActive, SqlDbType.VarChar).Value = (menuItem.Active == true) ? Constants.valueYes : Constants.valueNo;
                command.Parameters.Add(Constants.atDateOfLaunch, SqlDbType.Date).Value = menuItem.DateOfLaunch;
                command.Parameters.Add(Constants.atCategory, SqlDbType.VarChar).Value = menuItem.Category;
                command.Parameters.Add(Constants.atFreeDelivery, SqlDbType.VarChar).Value = (menuItem.FreeDelivery == true) ? Constants.valueYes : Constants.valueNo;
                command.Parameters.Add(Constants.atId, SqlDbType.Int).Value = menuItem.Id;

                command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// This menthod is used to get the menu item for  a particular id entered from the user
        /// </summary>
        /// <param name="menuItemId">This the id from the user for modification</param>
        /// <returns></returns>
        public MenuItem GetMenuItem(long menuItemId){
            MenuItem menuItem = new MenuItem();
            using (SqlConnection connection = new SqlConnection(callConnection)){
                connection.Open();
                SqlCommand command = new SqlCommand{
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._getItemById
                };
                command.Parameters.Add(Constants.atId,SqlDbType.Int).Value = menuItemId;
                SqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read()){
                    menuItem.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuId)));
                    menuItem.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuName)));
                    menuItem.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuPrice)));
                    menuItem.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuActive))).Equals(Constants.valueYes, StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menuItem.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuDateOfLaunch)));
                    menuItem.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuCategory)));
                    menuItem.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuFreeDelivery))).Equals(Constants.valueYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);
                }
            }
            return menuItem;
        }
    }
}
